package com.project.mykes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

public class MedActivity extends AppCompatActivity {

    int[] itemsarray = new int[]{
            R.drawable.med1,
            R.drawable.med2,
            R.drawable.med3,
            R.drawable.med4,
            R.drawable.med5,
            R.drawable.med6,
            R.drawable.med7,
            R.drawable.med8,
            R.drawable.med9,
    };

    String[] titleArray = new String[]{
            "Diabetes Tablet",
            "Sanmol Paracetamol",
            "Becom Zet Tablet",
            "Abbotic 500 mg",
            "Sumagestic Tablet",
            "Acetin 500 EFF",
            "Aciclovir Sampharindo",
            "Aclonan 50 mg",
            "Actifed Cough",
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_med);

        GridView gridView = findViewById(R.id.grid_view);

        GridViewAdapter baseAdapter = new GridViewAdapter(this, itemsarray, titleArray);
        gridView.setAdapter(baseAdapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent iDetailMed = new Intent(MedActivity.this, DetailMedActivity.class);
                startActivity(iDetailMed);
            }
        });
    }
}