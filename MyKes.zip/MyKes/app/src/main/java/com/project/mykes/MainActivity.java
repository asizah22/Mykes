package com.project.mykes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    private LinearLayout btnSick;
    private LinearLayout btnMed;
    private LinearLayout btnConsul;
    private ImageView btnHome;
    private ImageView btnCart;
    private ImageView btnMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSick = findViewById(R.id.btn_sick);
        btnMed = findViewById(R.id.btn_med);
        btnConsul = findViewById(R.id.btn_consul);
        btnHome = findViewById(R.id.btn_home);
        btnCart = findViewById(R.id.btn_cart);
        btnMessage = findViewById(R.id.btn_message);

        setListeners();
    }

    private void setListeners() {
        btnSick.setOnClickListener(v -> {
            startActivity(new Intent(this, SicknessActivity.class));
        });

        btnHome.setOnClickListener(v -> {
            startActivity(new Intent(this, SicknessActivity.class));
        });

        btnMed.setOnClickListener(v -> {
            startActivity(new Intent(this, MedActivity.class));
        });

        btnCart.setOnClickListener(v -> {
            startActivity(new Intent(this, MedActivity.class));
        });

        btnConsul.setOnClickListener(v -> {
            startActivity(new Intent(this, DoctorActivity.class));
        });

        btnMessage.setOnClickListener(v -> {
            startActivity(new Intent(this, DoctorActivity.class));
        });
    }
}