package com.project.mykes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

public class DoctorActivity extends AppCompatActivity {
    private LinearLayout btnDoctorOne;
    private LinearLayout btnDoctorTwo;
    private LinearLayout btnDoctorThree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor);

        btnDoctorOne = findViewById(R.id.btn_doctor_1);
        btnDoctorTwo = findViewById(R.id.btn_doctor_2);
        btnDoctorThree = findViewById(R.id.btn_doctor_3);

        btnDoctorOne.setOnClickListener(v -> {
            startActivity(new Intent(this, DetailDoctor.class));
        });

        btnDoctorTwo.setOnClickListener(v -> {
            startActivity(new Intent(this, DetailDoctor.class));
        });

        btnDoctorThree.setOnClickListener(v -> {
            startActivity(new Intent(this, DetailDoctor.class));
        });
    }
}